
Profiling a simple molecular dynamics simulation code
=====================================================

Compilation
-----------
    cd c   # or cd f90 if you prefer Fortran
    make clean; make
    ln -s ../input/atoms.in
    ln -s ../input/mdmorse.in
    ./mdmorse   # This might take some time

Profiling
---------
Follow the instructions given in lectures.

